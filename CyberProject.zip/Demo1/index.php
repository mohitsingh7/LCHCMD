<!DOCTYPE html>
<head>
	<meta charset='UTF-8' />
	
	<title>DEMO Page - 1</title>
	
	<link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/style.css' />
	<link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/prettify.css' />
	<style>
		#source-code { display: none; position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255,255,255,0.8); }
		#source-code:target { display: block; }
		#source-code pre { padding: 20px; font: 14px/1.6 Monaco, Courier, MonoSpace; margin: 50px auto; background: rgba(0,0,0,0.8); color: white; width: 80%; height: 80%; overflow: auto; }
		#source-code pre a, #source-code pre a span { text-decoration: none; color: #00ccff !important; }
		#x { position: absolute; top: 30px; left: 10%; margin-left: -41px; }
		.button { background: #00ccff; padding: 10px 20px; color: white; text-decoration: none; -moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; }
	</style>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<script src="http://css-tricks.com/examples/ViewSourceButton/prettify/prettify.js"></script>
	<script>
		$(function() {
			$("<pre />", {
				"html":   '&lt;!DOCTYPE html>\n&lt;html>\n' + 
						$("html")
							.html()
							.replace(/[<>]/g, function(m) { return {'<':'&lt;','>':'&gt;'}[m]})
							.replace(/((ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?)/gi,'<a href="$1">$1</a>') + 
						'\n&lt;/html>',
				"class": "prettyprint"
			}).appendTo("#source-code");
			
			prettyPrint();
		});
	</script>
</head>

<body>

	<div id="page-wrap">
	
		<h1>This is a DEMO Page 1.</h1>

		<p>This is a demo page for educational purpose. Changes made on this page will be easily detected when we will verify the content. </p>

		<a class="button" href="#source-code" id="view-source">View Source Code</a>
		
		<a class="button" href="http://naman-shah.000webhostapp.com/" id="view-source">Verify</a>
		
		<p style="font-size:22px"><br> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
		
		<div id="source-code">
			<a href="#" id="x"><img src="http://css-tricks.com/examples/ViewSourceButton/images/x.png" alt="close"></a>
		</div>
	
	</div>
	
	<script type="text/javascript">
		var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
		document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
		</script><script src="http://www.google-analytics.com/ga.js" type="text/javascript"></script>
		<script type="text/javascript">
		var pageTracker = _gat._getTracker("UA-68528-29");
		pageTracker._initData();
		pageTracker._trackPageview();
	</script> 
	
</body>

</html>